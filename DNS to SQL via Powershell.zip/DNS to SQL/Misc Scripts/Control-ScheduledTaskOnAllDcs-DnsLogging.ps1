﻿<# 
.SYNOPSIS 
    Using remoting, start the specified task for each DC (these are coded below)
.EXAMPLE 
    PS Start-DnsLoggingScheduledTaskOnAllDcs.ps1 [$Cred]
.NOTES 
	Author: Don Hess
    Version History:
    1.0    2016-07-07   Release
#>
Param(
    [Parameter(Mandatory=$true,
			   ValueFromPipeline=$true,
               ValueFromPipelineByPropertyName=$true,
               Position=0,
			   HelpMessage='Start or Stop')]
#    [ValidateSetAttribute("Start","Stop",IgnoreCase = $false)] # Ignore case is true by default
    [ValidateSet("Start","Stop")]
    [string[]] $Action,
    [Parameter(Mandatory=$false,
			   ValueFromPipeline=$true,
               ValueFromPipelineByPropertyName=$true,
               Position=1,
			   HelpMessage='PS remoting credential object')]
    [System.Management.Automation.PSCredential] $Cred
)
function Create-TaskObjectStore([array] $aInfo) {
    $oReturned = New-Object -TypeName System.Management.Automation.PSObject
    Add-Member -InputObject $oReturned -MemberType NoteProperty -Name Name -Value $aInfo[0]
    Add-Member -InputObject $oReturned -MemberType NoteProperty -Name Action -Value $aInfo[1]
    ,$oReturned
}
$scriptBlock1 = {
    param ($oSingleTaskCustomSb) # Param for the scriptblock input
    function Control-ScheduledTask(
      [parameter(Position=0)] $oSingleTaskCustomFunc
      ) {
        Begin {
            $TASK_STATE = @{0 = "Unknown"; 1 = "Disabled"; 2 = "Queued"; 3 = "Ready"; 4 = "Running"}
            $ACTION_TYPE = @{0 = "Execute"; 5 = "COMhandler"; 6 = "Email"; 7 = "ShowMessage"}

            # Try to create the TaskService object on the local computer; throw an error on failure
            try {
                $TaskService = New-Object -ComObject "Schedule.Service"
            }
            catch [System.Management.Automation.PSArgumentException] {
                throw $_
            }
        }
        Process {
            $TaskService.Connect()
            $oSingleTask = ($TaskService.GetFolder('\')).GetTask($oSingleTaskCustomFunc.Name)
            if ($oSingleTaskCustomFunc.Action -eq 'Start') {
                if (($oSingleTask.State -eq 2) -or ($oSingleTask.State -eq 3)) {
                    $oSingleTask.Run('') | Out-Null
                }
            }
            if ($oSingleTaskCustomFunc.Action -eq 'Stop') {
                if ($oSingleTask.State -eq 4)  {
                    $oSingleTask.Stop('') | Out-Null
                }
            }
        }
    } # End Control-ScheduledTask function
    # List your tasks that are in the root task scheduler folder
    Control-ScheduledTask $oSingleTaskCustomSb
} # End scriptblock1
if ($null -eq $Cred) {
	$Cred = Get-Credential
}
Import-Module ActiveDirectory
# Get all DC as they have the scheduled task)
$aDcs = Get-ADDomainController -Filter * | Select -Expand Name | Sort
$aDcs | ForEach-Object {
	$sDcName = $_
	Write-Host "Working on $sDcName"
	try {
		$sessionSrv1 = New-PSSession -ComputerName $sDcName -Credential $Cred -ErrorAction Stop
		Write-Host "  Session created for $sDcName"
        
        $sName = '\DNS_Cache_Logging_to_SQL'
        $oSingleTaskCustom = Create-TaskObjectStore @($sName, $Action)
		$oSingeResult = (Invoke-Command -Session $sessionSrv1 -ScriptBlock $scriptBlock1 -ArgumentList $oSingleTaskCustom -ErrorAction Stop)
        $sName = '\DNS_Query_Logging_to_SQL'
        $oSingleTaskCustom = Create-TaskObjectStore @($sName, $Action)
		$oSingeResult = (Invoke-Command -Session $sessionSrv1 -ScriptBlock $scriptBlock1 -ArgumentList $oSingleTaskCustom -ErrorAction Stop)

        Write-Host "  Tasks action '$Action' succeeded on $sDcName"
		if ($Action -eq 'Start') {
            Write-Host "  Waiting 60 seconds before starting next server"
            Start-Sleep 60
        }
	}
	catch { # Just set up a dummy object so the user sees something didn't work
		$err = $_
		$textOut = "Error while on $sDcName " + $err.Exception.Message.ToString()
        Write-Host $textOut
    }
	Remove-PSSession $sessionSrv1 -ErrorAction SilentlyContinue
}
