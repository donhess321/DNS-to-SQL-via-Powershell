
-- Search all DNS server cached records in the database regaurdless
-- of whether it is in use.  Let's you see if you have ever seen this record.
SELECT 
	 A.[RecordID]
	,A.[TextRepresentation]
	,A.[RecordType]
	,A.[DomainName]
	,A.[OwnerName]
	,A.[RecordData]	 -- Search this for IP as A records = IP, CNAME records = another name
	,A.[TTL]
	,A.[IPAddress]  -- Only populated for A records
	,A.[MailExchange]
	,A.[PTRDomainName]
	,A.[PrimaryName]
	,A.[SRVDomainName]
	,A.[Port]
	,A.[Preference]
	,A.[PSComputerName]
	,A.[GMTOffset_PSComputer]
FROM [DNS_Logging].[dbo].[Records] A
--WHERE A.[OwnerName] LIKE '%ch-syscon-test1%'
--WHERE A.[RecordData] = '163.172.151.248'
WHERE A.[TextRepresentation] LIKE '%192.169.82.86%'
ORDER BY A.[RecordID] DESC

