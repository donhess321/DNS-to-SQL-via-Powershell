
# Run the daily SQL stored procedures.

# Halt on any error
$ErrorActionPreference = "Stop"

# Setup SQL Connection
$sSqlSec = 'SSPI'
$sSqlServer = 'min-bmr-itdt20'
$sSqlDb = 'DNS_Logging'
$sSqlConnString = "Integrated Security = $sSqlSec; Server = $sSqlServer; Database = $sSqlDb;"

$oSqlConn = New-Object System.Data.SqlClient.SqlConnection
$oSqlConn.ConnectionString = $sSqlConnString
$oSqlCmd = New-Object System.Data.SqlClient.SqlCommand
$oSqlCmd.CommandText = "EXEC [dbo].[sp_Delete_Old_History]"
$oSqlCmd.Connection = $oSqlConn
$oSqlConn.Open()
$rowCount = $oSqlCmd.ExecuteNonQuery()
$oSqlConn.Close()

$oSqlConn = New-Object System.Data.SqlClient.SqlConnection
$oSqlConn.ConnectionString = $sSqlConnString
$oSqlCmd = New-Object System.Data.SqlClient.SqlCommand
$oSqlCmd.CommandText = "EXEC [dbo].[sp_Reorganize_All_Indexes]"
$oSqlCmd.Connection = $oSqlConn
$oSqlConn.Open()
$rowCount = $oSqlCmd.ExecuteNonQuery()
$oSqlConn.Close()
