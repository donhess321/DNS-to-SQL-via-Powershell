Set-StrictMode -Version latest -Verbose

function Setup-EventLogging() {
    # Resiter this script as a source to write to the Application log, PS v2+
    $eventLog = New-Object System.Diagnostics.EventLog
    $eventType = [System.Diagnostics.EventLogEntryType]::Information
    $eventID = 100
    $eventLog.Log = "Application"
    $eventLog.Source = "DNS_CacheRecord_Logging"
    $sDesc = "Creation of Event Logging Registration"
    $eventLog.WriteEntry($sDesc,$eventType,$eventID)
}

function Get-DNSServerCacheToSQL(
    [Parameter(Mandatory=$true,
               Position=0,
               ValueFromPipeline=$false,
               ValueFromPipelineByPropertyName=$true,
               HelpMessage='SQL connection object')] 
        [System.Data.SqlClient.SqlConnection] $oSqlConn,
    [Parameter(Mandatory=$true,
               Position=1,
               ValueFromPipeline=$false,
               ValueFromPipelineByPropertyName=$true,
               HelpMessage='DNS Server to query')] 
        [string] $sDnsServerFQName,
    [Parameter(Mandatory=$true,
               Position=2,
               ValueFromPipeline=$false,
               ValueFromPipelineByPropertyName=$true,
               HelpMessage='DNS server Timezone offset. +/-00 from GMT')]
        [string] $DnsServerTzOffset=''
    ) {
    <# 
    .Synopsis 
	Get DNS Server cache to an SQL database
    
    .DESCRIPTION 
	Get DNS Server cache to an SQL database.
    
    .PARAMETER oSqlConn
	Microsoft SQL server connection object  
    
    .PARAMETER sDnsServerFQName
	DNS server fully qualified hostname
    
    .PARAMETER DnsServerTzOffset
    The timezone offset of DNS server from GMT in the format +/-00

    .EXAMPLE 
	Get-DNSServerCacheToSQL -oSqlConn $oSqlConn -sDnsServerFQName $sDnsServerFQName 
    
    .LINKS 
    NA
    
    .NOTES 
    PS version supported: 2+
    
    Run with the 'Setup-EventLogging' function once as administrator so the event 
    source in this script will register with the Application log.
    
	Note that the DNS cache refreshes certain entries as you are reading it.  
	If you take a long time to read the cache there will be a slightly different 
	timestamps as records are appended to the end of the cache and you read them.  
	You will also have  records flushed from cache as you are using them so 
	DnsServerName will be $null.  There are workarounds noted in the code to 
	account for these issues.
	
	Author:
	Don Hess
	Version History:
	1.0    2016-05-12   Release
    #> 


Begin {
    # Halt on any error
    $ErrorActionPreference = "Stop"

    function DnsCacheTableFactory() {
        # This must match the SQL Stored Procedure data type exactly

	    $oDataTable = New-Object System.Data.DataTable("dt1")
	
	    # Create a new DataColumns
	    $oDataColumn =  New-Object System.Data.DataColumn
	    $oDataColumn.ColumnName = "RecordID"
	    $oDataColumn.DataType = "Int64"
	    $oDataTable.Columns.Add($oDataColumn)

	    $oDataColumn =  New-Object System.Data.DataColumn
	    $oDataColumn.ColumnName = "TextRepresentation"
	    $oDataColumn.DataType = "String"
	    $oDataTable.Columns.Add($oDataColumn)

	    $oDataColumn =  New-Object System.Data.DataColumn
	    $oDataColumn.ColumnName = "RecordType"
	    $oDataColumn.DataType = "String"
	    $oDataTable.Columns.Add($oDataColumn)

	    $oDataColumn =  New-Object System.Data.DataColumn
	    $oDataColumn.ColumnName = "DomainName"
	    $oDataColumn.DataType = "String"
	    $oDataTable.Columns.Add($oDataColumn)

	    $oDataColumn =  New-Object System.Data.DataColumn
	    $oDataColumn.ColumnName = "OwnerName"
	    $oDataColumn.DataType = "String"
	    $oDataTable.Columns.Add($oDataColumn)
	    $oDataColumn = $null

	    $oDataColumn =  New-Object System.Data.DataColumn
	    $oDataColumn.ColumnName = "RecordData"
	    $oDataColumn.DataType = "String"
	    $oDataTable.Columns.Add($oDataColumn)

	    $oDataColumn =  New-Object System.Data.DataColumn
	    $oDataColumn.ColumnName = "TTL"
	    $oDataColumn.DataType = "int"
	    $oDataTable.Columns.Add($oDataColumn)

	    $oDataColumn =  New-Object System.Data.DataColumn
	    $oDataColumn.ColumnName = "Timestamp"
	    $oDataColumn.DataType = "DateTime"
	    $oDataTable.Columns.Add($oDataColumn)

	    $oDataColumn =  New-Object System.Data.DataColumn
	    $oDataColumn.ColumnName = "GMTTimestamp"
	    $oDataColumn.DataType = "DateTime"
	    $oDataTable.Columns.Add($oDataColumn)

        $oDataColumn =  New-Object System.Data.DataColumn
	    $oDataColumn.ColumnName = "IPAddress"
	    $oDataColumn.DataType = "String"
	    $oDataTable.Columns.Add($oDataColumn)

	    $oDataColumn =  New-Object System.Data.DataColumn
	    $oDataColumn.ColumnName = "MailExchange"
	    $oDataColumn.DataType = "String"
	    $oDataTable.Columns.Add($oDataColumn)

	    $oDataColumn =  New-Object System.Data.DataColumn
	    $oDataColumn.ColumnName = "PTRDomainName"
	    $oDataColumn.DataType = "String"
	    $oDataTable.Columns.Add($oDataColumn)

	    $oDataColumn =  New-Object System.Data.DataColumn
	    $oDataColumn.ColumnName = "PrimaryName"
	    $oDataColumn.DataType = "String"
	    $oDataTable.Columns.Add($oDataColumn)

	    $oDataColumn =  New-Object System.Data.DataColumn
	    $oDataColumn.ColumnName = "SRVDomainName"
	    $oDataColumn.DataType = "String"
	    $oDataTable.Columns.Add($oDataColumn)

	    $oDataColumn =  New-Object System.Data.DataColumn
	    $oDataColumn.ColumnName = "Port"
	    $oDataColumn.DataType = "String"
	    $oDataTable.Columns.Add($oDataColumn)

	    $oDataColumn =  New-Object System.Data.DataColumn
	    $oDataColumn.ColumnName = "Preference"
	    $oDataColumn.DataType = "String"
	    $oDataTable.Columns.Add($oDataColumn)

	    $oDataColumn =  New-Object System.Data.DataColumn
	    $oDataColumn.ColumnName = "PSComputerName"
	    $oDataColumn.DataType = "String"
	    $oDataTable.Columns.Add($oDataColumn)

	    $oDataColumn =  New-Object System.Data.DataColumn
	    $oDataColumn.ColumnName = "GMTOffset_PSComputer"
	    $oDataColumn.DataType = "String"
	    $oDataTable.Columns.Add($oDataColumn)

	    $oDataColumn =  New-Object System.Data.DataColumn
	    $oDataColumn.ColumnName = "DnsServerName"
	    $oDataColumn.DataType = "String"
	    $oDataTable.Columns.Add($oDataColumn)

	    $oDataColumn =  New-Object System.Data.DataColumn
	    $oDataColumn.ColumnName = "ServerID"
	    $oDataColumn.DataType = "Int64"
	    $oDataTable.Columns.Add($oDataColumn)

	    ,$oDataTable
    } # End DnsCacheTableFactory
    function Add-DnsResourceRecordToDataTable( 
        [Parameter(Mandatory=$true)] [System.Data.DataTable] $oDataTable,
	    [Parameter(Mandatory=$true)] $oDnsRR
        ) {
	    # Convert a DNS Resource Records to a DataRow and attached to DataTable
	    # Input:   Datatable that is to receive the new resource record
        #          Single DNS resource record from Get-WMI
        # Also:    $regRecType, $dtStartOfRun, $sDnsServerFQName, $sPSComputerTzOffset from outside of this function
	    # Returns: --
        $Matches = $null
	
        # Create new row object and poplulate it
        [object] $oDataRow = $oDataTable.NewRow()

        $oDataRow.TextRepresentation = $oDnsRR.TextRepresentation
        $oDnsRR.__CLASS -match $regRecType | Out-Null
        $oDataRow.RecordType = $Matches.RecordType
        $oDataRow.DomainName = $oDnsRR.DomainName
        $oDataRow.OwnerName = $oDnsRR.OwnerName
        $oDataRow.RecordData = $oDnsRR.RecordData
        $oDataRow.TTL = $oDnsRR.TTL
        $oDataRow.Timestamp = [datetime] $dtStartOfRun
        # Next line does NOT account for 30min offset countries!!!
        $oDataRow.GMTTimestamp = $oDataRow.Timestamp.AddMinutes(([int] $DnsServerTzOffset)*-60) # Need inverse number so we end up at GMT.  
        # DnsServerName will be $null if the cache has expired and been flushed
        if ($null -eq $oDnsRR.DnsServerName) { 
            $oDataRow.DnsServerName = $sDnsServerFQName
        } else {
            $oDataRow.DnsServerName = $oDnsRR.DnsServerName
        }
        if ($null -eq $oDnsRR.PSComputerName) {
            $oDataRow.PSComputerName = $env:COMPUTERNAME
        } else {
            $oDataRow.PSComputerName = $oDnsRR.PSComputerName
        }
        $oDataRow.GMTOffset_PSComputer = $sPSComputerTzOffset
        # Record type specific
        try { $oDataRow.IPAddress = $oDnsRR.IPAddress } catch { Out-Null }
        try { $oDataRow.MailExchange = $oDnsRR.MailExchange } catch { Out-Null }
        try { $oDataRow.PTRDomainName = $oDnsRR.PTRDomainName } catch { Out-Null }
        try { $oDataRow.Port = $oDnsRR.Port } catch { Out-Null }
        try { $oDataRow.Preference = $oDnsRR.Preference } catch { Out-Null }
        try { $oDataRow.PrimaryName = $oDnsRR.PrimaryName } catch { Out-Null }
        try { $oDataRow.SRVDomainName = $oDnsRR.SRVDomainName } catch { Out-Null }
    
        # Add new row to table
        $oDataTable.Rows.Add($oDataRow)
    } # End  Add-DnsResourceRecordToDataTable
    function Upload-DataTableToSqlDnsServerRecordLogging(
        [System.Data.SqlClient.SqlConnection] $oOpenSqlConn, 
        [System.Data.DataTable] $oDataTable
        ) {
        # Input:   An already open SqlClient connection object
        #          DataTable that EXACTLY matches the table parameter, user defined data type
	    # Returns: NA
        try {
	        # Create SqlCommand object, define command text, and set the connection
	        $oSqlCmd = New-Object System.Data.SqlClient.SqlCommand
	        $oSqlCmd.CommandText = "EXEC [dbo].[sp_Insert_Server_Dns_Records] @tvInputRO"
	        $oSqlCmd.Connection = $oOpenSqlConn
	        # Add parameters to pass values to the stored procedure.  
            # DataType sent to server must match EXACTLY with this DataTable
	        $oSqlCmd.Parameters.AddWithValue("@tvInputRO", $oDataTable) | Out-Null
	        # http://msdn.microsoft.com/en-us/library/system.data.sqlclient.sqlparameter%28v=vs.110%29.aspx
	        $oSqlCmd.Parameters[0].TypeName = 'dbo.DnsRecordWithServerType' # Name of the user defined data type in SQL
            $rowCount = $oSqlCmd.ExecuteNonQuery()
        }
        catch {
            $err = $_
            $sCrashLog = 'C:\Users\'+$env:USERNAME+'\DNSCacheTableCrashLog.csv'
            $oDataTable | Export-Csv -Path $sCrashLog -ErrorAction SilentlyContinue
            $textOut = 'An error has occured.  A log file of the data that cause the crash has been written here:'
            Write-Debug $textOut
            Write-Debug $sCrashLog
            $sDesc = $textOut + "`n" + $sCrashLog
            $eventLog.WriteEntry($sDesc,$eventType,$eventID)
            $sDesc = $err.Exception.Message.ToString() + "`nLine " + `
            $err.get_InvocationInfo().ScriptLineNumber.ToString() + ": " + $err.get_InvocationInfo().Line + "`n"
            $eventLog.WriteEntry($sDesc,$eventType,$eventID)
            throw $err
        }
    }
    function Get-SqlErrorNextAttempt([System.Management.Automation.ErrorRecord] $err, [int] $iSecDelay) {
        # Input:    An error object, the number of seconds in the future to add if the error matches
        # Returns:  The current date time if the error is one we don't care about
        #           A future date time if the error matches one to act on
        $dtReturned = Get-Date
        if ($err.FullyQualifiedErrorId.ToString() -ne 'SqlException') {
            return $dtReturned
        }
        $sErrorRecord = $dtReturned.ToString()+'  '+$err.Exception.Message.ToString() + "`nLine " + `
            $err.get_InvocationInfo().ScriptLineNumber.ToString() + ": " + $err.get_InvocationInfo().Line + "`n"
        $sTextOut = "Found SQL error: "+$sErrorRecord
        if ($sErrorRecord.Contains('Exception calling "Open"') `
        -or $sErrorRecord.Contains('Connection Timeout Expired')) {
            # $oSqlConn.Open() fails to find the SQL server or a specific SQL instance
            $sDesc = $sErrorRecord
            $eventLog.WriteEntry($sDesc,$eventType,$eventID)
            Write-Debug $sTextOut
            return $dtReturned.AddSeconds($iSecDelay)
        }
        if ($sErrorRecord.Contains('Exception calling "ExecuteNonQuery"')) {
            # Connection opened OK, SQL server could not find the stored procedure to run it
            # Connection opened OK, we tried to run the stored procedure but something within the SQL server failed to run
            if ($sErrorRecord.Contains('Could not find stored procedure') `
            -or $sErrorRecord.Contains('Timeout expired') `
            -or $sErrorRecord.Contains('Database Engine cannot obtain a LOCK resource at this time') `
            -or $sErrorRecord.Contains('was deadlocked on lock resources')) {
                $sDesc = $sErrorRecord
                $eventLog.WriteEntry($sDesc,$eventType,$eventID)
                Write-Debug $sTextOut
                return $dtReturned.AddSeconds($iSecDelay)
            }
        }
        return $dtReturned
    } # End Get-SqlErrorNextAttempt
    function Sleep-Until([Datetime] $dtFuture) {
        $dtNow = Get-Date
        $iSec = [System.Math]::ceiling(($dtFuture - $dtNow).totalseconds)
        if ($iSec -gt 0) {
            Start-Sleep -Seconds $iSec 
        } else { return }
    }
    function Loop-UntilSqlErrorClears($oSqlTracking) {
        $bolLoop = $true
        while ($bolLoop) {
            $dtNow = Get-Date
            # Send our table to be uploaded to SQL and start over fresh
            # We need to delay SQL upload until it is time because of a previous error
            if ($dtNow -ge $oSqlTracking.dtSqlNextAttempt) { 
                $err = $null
                try {
                    if ($oSqlConn.State -eq 'Closed') {
                        $oSqlConn.Open()
                    }
                    Upload-DataTableToSqlDnsServerRecordLogging $oSqlConn $oSqlTracking.oTable
                    $oSqlTracking.oTable = DnsCacheTableFactory
                    $sTextOut = $oSqlTracking.iBatchCount.ToString()+" count reached"
					Write-Debug $sTextOut
            		$oSqlTracking.iBatchCount = 0
                    $oSqlTracking.iSqlErrorRetryCount = 0
                    $bolLoop = $false
                    return 
                }
                catch [Exception] {
                    $err = $_
                    $sErrorRecord = $err.FullyQualifiedErrorId.ToString()
                    if ($sErrorRecord.Contains('Exception calling "ExecuteNonQuery"')) {
                        # Connection opened OK, something happened to the connection in the middle 
                        # of the transaction.  We need to start over with a new connection after a few minutes
                        if ($sErrorRecord.Contains('A transport-level error has occurred') ) {
                            $sDesc = $sErrorRecord
                            $eventLog.WriteEntry($sDesc,$eventType,$eventID)
                            Write-Debug $sTextOut
                            $oSqlConn.Close()
                        }
                    }       
                    $sTextOut = 'Unprocessed batch count: '+$oSqlTracking.iBatchCount.ToString()
                    Write-Debug $sTextOut
                    # Check for SQL error
                    $oSqlTracking.dtSqlNextAttempt = Get-SqlErrorNextAttempt $err $oSqlTracking.iSqlErrorWaitTime
                    $dtNow = Get-Date
                    if ($oSqlTracking.dtSqlNextAttempt -le $dtNow) {
                        # Error is not SQL related, no reason to wait for anything
                        $sDesc = $dtNow.ToString() + $err.Exception.Message.ToString() + "`nLine " + `
                        $err.get_InvocationInfo().ScriptLineNumber.ToString() + ": " + $err.get_InvocationInfo().Line + "`n"
                        $eventLog.WriteEntry($sDesc,$eventType,$eventID)
                        throw $err
                    } 
                    else {
                        $oSqlTracking.iSqlErrorRetryCount++
                        # And just eat the error for now
                    }
                }
            }
            if ($oSqlTracking.iSqlErrorRetryCount -ge $oSqlTracking.iSqlErrorRetryMax) {
                # Max number of SQL retries reached
                $oSqlConn.Close()
                $sDesc = $dtNow.ToString() + $err.Exception.Message.ToString() + "`nLine " + `
                $err.get_InvocationInfo().ScriptLineNumber.ToString() + ": " + $err.get_InvocationInfo().Line + "`n"
                $eventLog.WriteEntry($sDesc,$eventType,$eventID)
                throw $err
            }
            Sleep-Until $oSqlTracking.dtSqlNextAttempt
        } # End while ($bolLoop)
    }
    function Create-SqlTrackingObject() {
        $oSqlTracking = New-Object -TypeName System.Management.Automation.PSObject
        Add-Member -InputObject $oSqlTracking -MemberType NoteProperty -Name iBatchMax -Value 500  # Number of records to batch.
        Add-Member -InputObject $oSqlTracking -MemberType NoteProperty -Name iBatchCount -Value 0
        Add-Member -InputObject $oSqlTracking -MemberType NoteProperty -Name iSqlErrorRetryMax -Value 3  # Number of times to retry after and SQL error
        Add-Member -InputObject $oSqlTracking -MemberType NoteProperty -Name iSqlErrorRetryCount -Value 0  # A counter, the number of SQL errors we have seen
        Add-Member -InputObject $oSqlTracking -MemberType NoteProperty -Name iSqlErrorWaitTime -Value 180  # Number of seconds to wait after an SQL error
        Add-Member -InputObject $oSqlTracking -MemberType NoteProperty -Name dtSqlNextAttempt -Value ([datetime] '2001-01-01 00:00:01')
        Add-Member -InputObject $oSqlTracking -MemberType NoteProperty -Name oTable -Value $null
        ,$oSqlTracking
    }
    # Setup error logging object
    $eventLog = New-Object System.Diagnostics.EventLog
    $eventType = [System.Diagnostics.EventLogEntryType]::Error
    $eventID = 400
    $eventLog.Log = "Application"
    $eventLog.Source = "DNS_CacheRecord_Logging"
    
    $regRecType = [regex] '^MicrosoftDNS_(?<RecordType>\S{1,8})Type$'
    $sPSComputerTzOffset = (Get-Date -UFormat %Z) # String +/-00 from GMT
} # End Begin section
Process {
    $oSqlTracking = Create-SqlTrackingObject
    if (($null -eq $sDnsServerFQName) -or ($sDnsServerFQName -eq '') -or ($sDnsServerFQName -eq '.')) {
        $oComputer = Get-WmiObject Win32_ComputerSystem
        $sDnsServerFQName = ($oComputer.Name+'.'+$oComputer.Domain)
    }
    $sDnsServerFQName = $sDnsServerFQName.ToLower()
    # Specify the types of text records you want.  https://technet.microsoft.com/en-us/library/dd197491%28v=ws.10%29.aspx
    $aRRTypes = @(
        'MicrosoftDNS_AAAAType',
        'MicrosoftDNS_AType',
        'MicrosoftDNS_CNAMEType',
        'MicrosoftDNS_MXType',
        'MicrosoftDNS_SOAType',
        'MicrosoftDNS_SRVType',
        'MicrosoftDNS_TXTType'
    )
    $aRRTypes | ForEach-Object {
        $sDnsRRType = $_
        $dtStartOfRun = Get-Date
        $oSqlTracking.oTable = DnsCacheTableFactory
        Write-Debug "$dtStartOfRun  Working on record type $sDnsRRType"

        # DNS class reference:  https://technet.microsoft.com/en-us/library/dd197491%28v=ws.10%29.aspx
        # This will get ALL cached records.  A, MX, PTR, NS, AAAA, etc...
        # Get-WmiObject -ComputerName . -Namespace root\MicrosoftDNS -class MicrosoftDNS_ResourceRecord
        # This will get only A record types.
        #Get-WmiObject -ComputerName . -Namespace root\MicrosoftDNS -class MicrosoftDNS_AType
        #$gwoDnsCache1 = Get-WmiObject -ComputerName lol-my-srv1.mydomain.com -Namespace root\MicrosoftDNS -class MicrosoftDNS_AType
        while ($oSqlConn.State -eq 'Closed') {
			# Try to open the SQL connection a few times
            if ($oSqlTracking.iSqlErrorRetryCount -ge $oSqlTracking.iSqlErrorRetryMax) {
                $sDesc = $err.Exception.Message.ToString() + "`nLine " + `
                $err.get_InvocationInfo().ScriptLineNumber.ToString() + ": " + $err.get_InvocationInfo().Line + "`n"
                $eventLog.WriteEntry($sDesc,$eventType,$eventID)
                throw $err
            }
            try { $oSqlConn.Open() } # And keep it open till we are done with RRType
            catch {
                $err = $_
                $oSqlTracking.dtSqlNextAttempt = Get-SqlErrorNextAttempt $err $oSqlTracking.iSqlErrorWaitTime
                $dtNow = Get-Date
                if ($oSqlTracking.dtSqlNextAttempt -le $dtNow) {
                    # Error is not SQL related, no reason to wait for anything
                    $sDesc = $err.Exception.Message.ToString() + "`nLine " + `
                    $err.get_InvocationInfo().ScriptLineNumber.ToString() + ": " + $err.get_InvocationInfo().Line + "`n"
                    $eventLog.WriteEntry($sDesc,$eventType,$eventID)
                    throw $err
                } else {
                    $oSqlTracking.iSqlErrorRetryCount++
                    Sleep-Until $oSqlTracking.dtSqlNextAttempt
                    # And just eat the error for now
                }
            } # End if statement
        } # End while loop
        $oSqlTracking.iSqlErrorRetryCount = 0
		# Process all our cached resource records
        try {
            Setup-EventLogging
            Get-WmiObject -ComputerName $sDnsServerFQName -Namespace root\MicrosoftDNS -class $sDnsRRType | ForEach-Object { 
                if ($null -eq $_) {
                    return # Break out of current pipeline object (which is none anyway)
                }
                Add-DnsResourceRecordToDataTable $oSqlTracking.oTable $_
                $oSqlTracking.iBatchCount++
                if ($oSqlTracking.iBatchCount -ge $oSqlTracking.iBatchMax) {
                    # Send our table to be uploaded to SQL and start over fresh
                    $sTextOut = '$oSqlTracking.oTable.Rows.Count is: '+$oSqlTracking.oTable.Rows.Count.ToString()
                    #Write-Debug $sTextOut
                    Loop-UntilSqlErrorClears $oSqlTracking
                } # End  if ($iBatchCount -ge $iBatchMax)
    		}
            # Send the remaining records that total less than the batch
            Loop-UntilSqlErrorClears $oSqlTracking
            $oSqlConn.Close()
        }
        catch {
            $err = $_
            $sDesc = $err.Exception.Message.ToString() + "`nLine " + `
            $err.get_InvocationInfo().ScriptLineNumber.ToString() + ": " + $err.get_InvocationInfo().Line + "`n"
            $eventLog.WriteEntry($sDesc,$eventType,$eventID)
            throw $err
        }
    } # End $aRRTypes | ForEach-Object {
} # End -Process
} # End Get-DNSServerCacheToSQL function

function Start-Get-DNSServerCacheToSQL($bolLoop=$false) {
    # This contents can go in some other script and passed to the Get-DNSServerCacheToSQL function
    Setup-EventLogging
    
    # Setup SQL Connection
    $sSqlSec = 'SSPI'
    $sSqlServer = 'phl-bus-sql1'
    $sSqlDb = 'DNS_Logging'
    $sSqlConnString = "Integrated Security = $sSqlSec; Server = $sSqlServer; Database = $sSqlDb;"
    $oSqlConn = New-Object System.Data.SqlClient.SqlConnection
    $oSqlConn.ConnectionString = $sSqlConnString

    $sDnsServerFQName = '.'
    $DnsServerTzOffset = (Get-Date -UFormat %Z) # String +/-00 from GMT
    if ($bolLoop) {
        While ($true) {
            Get-DNSServerCacheToSQL -oSqlConn $oSqlConn -sDnsServerFQName $sDnsServerFQName -DnsServerTzOffset $DnsServerTzOffset
            Start-Sleep 900
        }
    }
    else {
        Get-DNSServerCacheToSQL -oSqlConn $oSqlConn -sDnsServerFQName $sDnsServerFQName -DnsServerTzOffset $DnsServerTzOffset
    }
}

Start-Get-DNSServerCacheToSQL -bolLoop $true




# Other resource record types
# MicrosoftDNS_AFSDBType
# MicrosoftDNS_ATMAType
# MicrosoftDNS_HINFOType
# MicrosoftDNS_ISDNType
# MicrosoftDNS_KEYType
# MicrosoftDNS_MBType
# MicrosoftDNS_MDType
# MicrosoftDNS_MFType
# MicrosoftDNS_MGType
# MicrosoftDNS_MINFOType
# MicrosoftDNS_MRType
# MicrosoftDNS_NSType
# MicrosoftDNS_NXTType
# MicrosoftDNS_PTRType
# MicrosoftDNS_RPType
# MicrosoftDNS_RTType
# MicrosoftDNS_SIGType
# MicrosoftDNS_WINSRType
# MicrosoftDNS_WINSType
# MicrosoftDNS_WKSType
# MicrosoftDNS_X25Type
