Set-StrictMode -Version latest -Verbose

function Setup-EventLogging() {
    # Resiter this script as a source to write to the Application log, PS v2+
    $eventLog = New-Object System.Diagnostics.EventLog
    $eventType = [System.Diagnostics.EventLogEntryType]::Information
    $eventID = 100
    $eventLog.Log = "Application"
    $eventLog.Source = "DNS_DebugLogLine_Logging"
    $sDesc = "Creation of Event Logging Registration"
    $eventLog.WriteEntry($sDesc,$eventType,$eventID)
}
function Get-DnsDebugLogLineToSql(
    	[Parameter(Mandatory=$true,
                   HelpMessage='Full DNS debug log file')]
        	[ValidateScript({Test-Path ($_)})]
        	[string] $DnsDebugLogFilePath,
        [Parameter(Mandatory=$true,
                   HelpMessage='SQL connection object')] 
            [System.Data.SqlClient.SqlConnection] $oSqlConn,
        [Parameter(Mandatory=$false,
                   HelpMessage='Fully Qualified DNS server name that created the log file.  Use "." to indicate local machine ')]
            [string] $DnsServerName='',
        [Parameter(Mandatory=$false,
                   HelpMessage='DNS server Timezone offset. +/-00 from GMT')]
            [string] $DnsServerTzOffset='',
        [Parameter(Mandatory=$false,
                   HelpMessage='Ignore these types of queries')]
            [array] $IgnoreQryType=@(),
        [Parameter(Mandatory=$false,
                   HelpMessage='Tail the file instead of fully parsing it')]
            [switch] $t=$false
    ) {
    <#
    .SYNOPSIS
    Reads the specified DNS debug log and uploads the process results to an SQL database.

    .DESCRIPTION
    Retrives all DNS query entries (Context:PACKET) in the specified DNS debug log for further 
    processing in Powershell. Entries in the file that are not of context PACKET are ignored.
    Incoming query request and response log lines can be parsed.  The results are uploaded
    to an SQL database.  The entire file can be processed or the tail option allows continuous 
    monitoring of the file.

    .PARAMETER DnsDebugLogFilePath
    Specifies the filepath to the DNS debug logfile.
    
    .PARAMETER DnsServerName
    The fully qualified name of the DNS server that created the log file.  
    An attempt is made to populate this by default if run on the DNS server.

    .PARAMETER DnsServerTzOffset
    The timezone offset of DNS server from GMT in the format +/-00
    An attempt is made to populate this by default if run on the DNS server.

    .PARAMETER IgnoreQryType
    Ignore these types of queries.  An array of query types PTR, MX, AAAA, etc.
    
    .PARAMETER t
    Switch to enable monitoring of the file via Tail.
    
    .INPUTS
    Takes the filepath of the DNS server's debug log
    MS SQL connection object
    DNS server name that create the log file
    Ignore array contents of query types
    Option to enable continuous monitoring of the log file
    
    .OUTPUTS
    Upload to an SQL database
    
    .EXAMPLE
    Get-DnsDebugLogLineToSql -DnsDebugLogFilePath "$($env:SystemRoot)\system32\dns\dns.log" -oSqlConn $oSqlConn
    
    .EXAMPLE
    Get-DnsDebugLogLineToSql -DnsDebugLogFilePath "c:\dns.log" -oSqlConn $oSqlConn `
                             -DnsServerName 'my_server.dom.com' -DnsServerTzOffset '-04'

    .EXAMPLE
    Get-DnsDebugLogLineToSql -DnsDebugLogFilePath 'c:\mylogfile.log' -oSqlConn $oSqlConn -IgnoreQryType @('PTR','MX')'
                             -DnsServerName 'my_server.dom.com' -t
    
    .LINK

    .NOTES
    PS version supported: 2+
    
    Run with the 'Setup-EventLogging' function once as administrator so the event 
    source in this script will register with the Application log.

    Author: 
	Don Hess
	Version History:
    1.0    2016-05-16   Release
    #>
Begin {
    # Halt on any error
    $ErrorActionPreference = "Stop"

    # Change switch paramater to boolean
    Try {
        if ( $t.GetType().Name -eq 'SwitchParameter' ) {
        	$t_temp = $t.ToBool()
        	Remove-Variable t
        	$t = $t_temp    # Scoping should be wide enough
            Remove-Variable t_temp
        }
    }
    Catch { $t = $false }
    $htQRLookup = @{''='Query';' '='Query';'R'='Response';
                               'Query'=' ';'Response'='R';} # Dual directional, Accounts for a trimmed Query result also
    $htOpCodeLookup = @{'Q'='Standard Query';'N'='Notify';'U'='Update';'?'='Unknown';
                        'Standard Query'='Q';'Notify'='N';'Update'='U';'Unknown'='?';} # Dual directional
    $htFlagsCharCodeLookup = @{[char] 'A'='Authoritative Answer';[char] 'T'='Truncated Response';[char] 'D'='Recursion Desired';[char] 'R'='Recursion Available';
                               'A'='Authoritative Answer';'T'='Truncated Response';'D'='Recursion Desired';'R'='Recursion Available';
                               'Authoritative Answer'='A';'Truncated Response'='T';'Recursion Desired'='D';'Recursion Available'='R';} # Dual directional
    function DnsLogTableFactory() {
        # This must match the SQL Stored Procedure data type exactly
        $oDataTable = New-Object System.Data.DataTable("dt1")

	    $oDataColumn =  New-Object System.Data.DataColumn
	    $oDataColumn.ColumnName = "QueryID"
	    $oDataColumn.DataType = "String"    # This is string so it can be NULL when passed to SP
	    $oDataTable.Columns.Add($oDataColumn)

        $oDataColumn =  New-Object System.Data.DataColumn
        $oDataColumn.ColumnName = "QuestionName"
        $oDataColumn.DataType = "String"
        $oDataTable.Columns.Add($oDataColumn)

        $oDataColumn =  New-Object System.Data.DataColumn
        $oDataColumn.ColumnName = "QuestionType"
        $oDataColumn.DataType = "String"
        $oDataTable.Columns.Add($oDataColumn)

        $oDataColumn =  New-Object System.Data.DataColumn
        $oDataColumn.ColumnName = "Date"
        $oDataColumn.DataType = "String"
        $oDataTable.Columns.Add($oDataColumn)

        $oDataColumn =  New-Object System.Data.DataColumn
        $oDataColumn.ColumnName = "Time"
        $oDataColumn.DataType = "String"
        $oDataTable.Columns.Add($oDataColumn)

        $oDataColumn =  New-Object System.Data.DataColumn
        $oDataColumn.ColumnName = "Timestamp"
        $oDataColumn.DataType = "DateTime"
        $oDataTable.Columns.Add($oDataColumn)

        $oDataColumn =  New-Object System.Data.DataColumn
        $oDataColumn.ColumnName = "GMTTimestamp"
        $oDataColumn.DataType = "DateTime"
        $oDataTable.Columns.Add($oDataColumn)

        $oDataColumn =  New-Object System.Data.DataColumn
        $oDataColumn.ColumnName = "ThreadID"
        $oDataColumn.DataType = "String"
        $oDataTable.Columns.Add($oDataColumn)

        $oDataColumn =  New-Object System.Data.DataColumn
        $oDataColumn.ColumnName = "Context"
        $oDataColumn.DataType = "String"
        $oDataTable.Columns.Add($oDataColumn)

        $oDataColumn =  New-Object System.Data.DataColumn
        $oDataColumn.ColumnName = "PacketID"
        $oDataColumn.DataType = "String"
        $oDataTable.Columns.Add($oDataColumn)

        $oDataColumn =  New-Object System.Data.DataColumn
        $oDataColumn.ColumnName = "IPType"
        $oDataColumn.DataType = "String"
        $oDataTable.Columns.Add($oDataColumn)

        $oDataColumn =  New-Object System.Data.DataColumn
        $oDataColumn.ColumnName = "SndOrRcv"
        $oDataColumn.DataType = "String"
        $oDataTable.Columns.Add($oDataColumn)

        $oDataColumn =  New-Object System.Data.DataColumn
        $oDataColumn.ColumnName = "RemoteIP"
        $oDataColumn.DataType = "String"
        $oDataTable.Columns.Add($oDataColumn)

        $oDataColumn =  New-Object System.Data.DataColumn
        $oDataColumn.ColumnName = "XID"
        $oDataColumn.DataType = "String"
        $oDataTable.Columns.Add($oDataColumn)

        $oDataColumn =  New-Object System.Data.DataColumn
        $oDataColumn.ColumnName = "QueryOrResponse"
        $oDataColumn.DataType = "String"
        $oDataTable.Columns.Add($oDataColumn)

        $oDataColumn =  New-Object System.Data.DataColumn
        $oDataColumn.ColumnName = "OpCode"
        $oDataColumn.DataType = "String"
        $oDataTable.Columns.Add($oDataColumn)

        $oDataColumn =  New-Object System.Data.DataColumn
        $oDataColumn.ColumnName = "Flags"
        $oDataColumn.DataType = "String"
        $oDataTable.Columns.Add($oDataColumn)

        $oDataColumn =  New-Object System.Data.DataColumn
        $oDataColumn.ColumnName = "FlagsCharCode"
        $oDataColumn.DataType = "String"
        $oDataTable.Columns.Add($oDataColumn)

        $oDataColumn =  New-Object System.Data.DataColumn
        $oDataColumn.ColumnName = "ResponseCode"
        $oDataColumn.DataType = "String"
        $oDataTable.Columns.Add($oDataColumn)

	    $oDataColumn =  New-Object System.Data.DataColumn
	    $oDataColumn.ColumnName = "PSComputerName"
	    $oDataColumn.DataType = "String"
	    $oDataTable.Columns.Add($oDataColumn)

	    $oDataColumn =  New-Object System.Data.DataColumn
	    $oDataColumn.ColumnName = "GMTOffset_PSComputer"
	    $oDataColumn.DataType = "String"
	    $oDataTable.Columns.Add($oDataColumn)

        $oDataColumn =  New-Object System.Data.DataColumn
        $oDataColumn.ColumnName = "DnsServerName"
        $oDataColumn.DataType = "String"
        $oDataTable.Columns.Add($oDataColumn)

        $oDataColumn =  New-Object System.Data.DataColumn
        $oDataColumn.ColumnName = "ServerID"
        $oDataColumn.DataType = "String"    # This is string so it can be NULL when passed to SP
        $oDataTable.Columns.Add($oDataColumn)

        $oDataColumn =  New-Object System.Data.DataColumn
        $oDataColumn.ColumnName = "RemoteIPID"
        $oDataColumn.DataType = "String"    # This is string so it can be NULL when passed to SP
        $oDataTable.Columns.Add($oDataColumn)

        ,$oDataTable
    } # End DnsLogTableFactory
    function Create-ReqRespLineRegex() {
    	# Create a regex object for a normal DNS Packet Debug Log line.  This covers Request and Response log lines.
        # http://www.iana.org/assignments/dns-parameters/dns-parameters.xhtml
        # Works on these types of lines:
        # 4/26/2016 8:45:38 AM 0B4C PACKET  0000000002706310 UDP Rcv 10.100.0.53    f055   Q [0001   D   NOERROR] A      (12)mrk-325-srv3(8)mydomain(3)com(0)
        # 4/26/2016 8:46:05 AM 0B4C PACKET  0000000002FD4B90 UDP Rcv 10.100.8.234    6cb6   Q [0001   D   NOERROR] PTR    (3)233(1)8(3)104(2)10(7)in-addr(4)arpa(0)
        # 4/26/2016 8:48:23 AM 0B4C PACKET  000000000263B4B0 UDP Rcv 172.16.1.250    3ebb   Q [0005 A D   NOERROR] A      (12)mrk-bus-srv3(9)mydomain1(3)com(0)
        # 4/26/2016 8:47:22 AM 0B4C PACKET  0000000006F6F860 UDP Rcv 172.16.1.250    b72d   Q [0005 A D   NOERROR] NS     (7)webmail(9)mydomain1(3)com(0)
        # 4/27/2016 8:21:53 AM 0B4C PACKET  00000000025597A0 UDP Rcv 10.7.0.20       61dc   Q [0201   D  SERVFAIL] A      (3)api(8)chatgame(2)me(0)
        # 5/26/2016 12:07:17 PM 12BC PACKET  00000000098A9610 UDP Rcv fe80::c1ce:b7db:47cc:5800 a8fb  Q [0001   D   NOERROR] A      (11)LOC-111-av1(9)mydomains(3)com(0)
        # 5/26/2016 12:09:15 PM 12BC PACKET  00000000079ADB50 UDP Rcv fe80::c1ce:b7db:47cc:5800 2644  Q [0001   D   NOERROR] SRV    (5)_ldap(4)_tcp(3)pdc(6)_msdcs(9)mydomains(3)com(0)
        # 5/26/2016 12:10:00 PM 12BC PACKET  00000000098A9610 UDP Rcv fe80::c1ce:b7db:47cc:5800 f402  Q [0001   D   NOERROR] A      (36)6d5a2c09-9b9f-434e-b74f-b3764f6e2560(6)_msdcs(9)mydomain1(3)com(0)
        # 5/26/2016 12:11:06 PM 12BC PACKET  00000000044F9D30 UDP Rcv fe80::c1ce:b7db:47cc:5800 f4d3  Q [0001   D   NOERROR] SRV    (5)_ldap(4)_tcp(6)loc-dc(6)_sites(11)LOC-111-DC1(9)mydomain1(3)com(0)
        # 5/26/2016 12:11:06 PM 12BC PACKET  000000000A987E90 UDP Rcv fe80::c1ce:b7db:47cc:5800 c0d8  Q [0001   D   NOERROR] A      (11)LOC-111-DC4(9)mydomain1(3)com(0)
        # These will NOT match
        # 4/27/2016 3:51:33 AM 0B4C PACKET  0000000002621DD0 UDP Rcv 10.104.8.54     009c   Q [1000       NOERROR]
        # 5/26/2016 12:00:34 PM 0B8C PACKET  000000000222E940 UDP Rcv 65.55.169.42    7b40 R Q [0180      FORMERR]

        $arrRegPrep = @()
    	$arrRegPrep += "(?<Date>^\d{1,2}\/\d{1,2}\/\d{4})"   # 4/26/2016
        $arrRegPrep += "(?<G1>\s)"  # Garbage
        $arrRegPrep += "(?<Time>\d{1,2}\:\d{1,2}\:\d{1,2}\s[AP]M)" # 8:53:56 PM
        $arrRegPrep += "(?<G1>\s)"  # Garbage
        $arrRegPrep += "(?<ThreadID>\S{3,4})"
        $arrRegPrep += "(?<G1>\s)"  # Garbage
        $arrRegPrep += "(?<Context>PACKET)"
        $arrRegPrep += "(?<G1>\s*)"  # Garbage
        $arrRegPrep += "(?<PacketID>[0-9A-Za-z]{8,16})" # 0000000003A91570
        $arrRegPrep += "(?<G1>\s)"  # Garbage
        $arrRegPrep += "(?<IPType>TCP|UDP)" # TCP or UDP
        $arrRegPrep += "(?<G1>\s)"  # Garbage
        $arrRegPrep += "(?<SndOrRcv>Snd|Rcv)" # Snd or Rcv
        $arrRegPrep += "(?<G1>\s)"  # Garbage
        $arrRegPrep += "(?<RemoteIP>\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}|[a-f,0-9,:]{3,39})" # IPV4 or IPv6.  IPv6 min is "::1", max is 39 chars
        $arrRegPrep += "(?<G1>\s*)"  # Garbage
        $arrRegPrep += "(?<XID>\S{4})" # Hex
        $arrRegPrep += "(?<G1>\s)"  # Garbage
        $arrRegPrep += "(?<QueryOrResponse>(\s{1}|R))" # ' '=Query or 'R'=Response
        $arrRegPrep += "(?<G1>\s)"  # Garbage
        $arrRegPrep += "(?<OpCode>Q|N|U|\?)" # Opcode Q=Standard Query, N=Notify, U=Update, ?=Unknown
        $arrRegPrep += "(?<G1>\s*\[)(?<Flags>\S{4})(?<G1>\s)(?<FlagsCharCode>[\sATDR]{3,5})(?<G1>\s)(?<ResponseCode>\w*)(?<G1>\])"
        $arrRegPrep += "(?<G1>\s)"  # Garbage
        #$arrRegPrep += "(?<QuestionType>A|SRV|PTR|MX|NS|AAAA|SOA|CNAME|IXFR|TXT)"
        $arrRegPrep += "(?<QuestionType>\S{1,10})"
        $arrRegPrep += "(?<G1>\s*)"  # Garbage
        $arrRegPrep += "(?<QuestionName>\(.*)"
        # Use .NET regex as it should be faster
        $regLine = [regex] ($arrRegPrep -join '')
        return $regLine
    }
    function Parse-DnsDebugLogLineToDataTable( 
     	[Parameter(Mandatory=$true)] [array] $aLines,
    	[Parameter(Mandatory=$true)] [regex] $regLine,
        [Parameter(Mandatory=$true)] [System.Data.DataTable] $oDataTable
        ) {
    	# Parse a DNS Debug Log line to a DataRow and attached to the specified DataTable
    	# Input:   Array of strings, one cell per line of text
        #          Regular expression to match to a single line
        #          Datatable that is to receive the new resource record
        # Also:    Needs $regQParSep='(\(\d{1,3}\))' $sPSComputerName, $sPSComputerTzOffset, $sDnsServerFQName defined outside this function
    	# Returns: -- (output is attached to the specified DataTable)
    	$aLines | ForEach-Object {
            if ( $_.Length -eq 0 ) {
                return # Break to next object in pipeline
            }
    		$Matches = $null
    		if ( $_ -match $regLine ) {
                if ( $Matches.QuestionType.Trim() -in $IgnoreQryType ) {
                    # Ignore this query type
                    return # Break to next object in pipeline
                }
                # Create new row object and poplulate it
                [object] $oDataRow = $oDataTable.NewRow()
                $oDataRow.QuestionName = ($Matches.QuestionName.Trim() -replace $regQParSep,'.').Trim('.') # Sub in periods and trim ends.
                $oDataRow.QuestionType = $Matches.QuestionType.Trim()
                $oDataRow.Date = $Matches.Date.Trim()
                $oDataRow.Time = $Matches.Time.Trim()
                $oDataRow.Timestamp = [datetime] ($oDataRow.Date+" "+$oDataRow.Time)
                # Next line does NOT account for 30min offset countries!!!
                $oDataRow.GMTTimestamp = $oDataRow.Timestamp.AddMinutes(([int] $DnsServerTzOffset)*-60) # Need inverse number so we end up at GMT.  
                #$oDataRow.ThreadID = $Matches.ThreadID.Trim()
                $oDataRow.Context = $Matches.Context.Trim()
                #$oDataRow.PacketID = $Matches.PacketID.Trim()
                $oDataRow.IPType = $Matches.IPType.Trim()
                $oDataRow.SndOrRcv = $Matches.SndOrRcv.Trim()
                $oDataRow.RemoteIP = $Matches.RemoteIP.Trim() # [ipaddress] $Matches.RemoteIP.Trim()
                #$oDataRow.XID = $Matches.XID.Trim()
                $oDataRow.QueryOrResponse = $htQRLookup[$Matches.QueryOrResponse] # Cannot trim because " "=Query
                $oDataRow.OpCode = $htOpCodeLookup[$Matches.OpCode.Trim()]
                #$oDataRow.Flags = $Matches.Flags.Trim()
                # Change single character flags to descriptions
                $sFlagsCharCode = $Matches.FlagsCharCode.Replace(' ','')
                $sFlagsCharCodeDesc = ''
                $iCount = $sFlagsCharCode.Length
                for ($i = 0; $i -lt $iCount; $i++) {
                	$sFlagsCharCodeDesc = $sFlagsCharCodeDesc + $htFlagsCharCodeLookup[$sFlagsCharCode[$i]] + ', '
                }
                $oDataRow.FlagsCharCode = $sFlagsCharCodeDesc.TrimEnd(', ')
                $oDataRow.ResponseCode = $Matches.ResponseCode.Trim()
                $oDataRow.PSComputerName = $sPSComputerName
                $oDataRow.GMTOffset_PSComputer = $sPSComputerTzOffset
                $oDataRow.DnsServerName = $sDnsServerFQName
                # Add new row to table
                $oDataTable.Rows.Add($oDataRow)
    		}
            else {
                Out-Null
                $sTextOut = 'Invalid parsed line: '+$_.ToString()
                Write-Debug $sTextOut       # Use this to view output:  $DebugPreference = 'Continue'
            }
	    }
    } # End Parse-DnsDebugLogLineToDataTable
    function Upload-DataTableToSqlDnsServerRecordLogging(
        [System.Data.SqlClient.SqlConnection] $oOpenSqlConn, 
        [System.Data.DataTable] $oDataTable
        ) {
        # Input:   An already open SqlClient connection object
        #          DataTable that EXACTLY matches the table parameter, user defined data type
	    # Returns: NA
	    # Create SqlCommand object, define command text, and set the connection
	    $oSqlCmd = New-Object System.Data.SqlClient.SqlCommand
        try {
            $oSqlCmd.CommandText = "EXEC [dbo].[sp_Insert_Dns_Debug_Queries] @tvInputRO"
	        $oSqlCmd.Connection = $oOpenSqlConn
	        # Add parameters to pass values to the stored procedure.  
            # DataType sent to server must match EXACTLY with this DataTable
	        $oSqlCmd.Parameters.AddWithValue("@tvInputRO", $oDataTable) | Out-Null
	        # http://msdn.microsoft.com/en-us/library/system.data.sqlclient.sqlparameter%28v=vs.110%29.aspx
	        $oSqlCmd.Parameters[0].TypeName = 'dbo.DnsDebugQueryType' # Name of the user defined data type in SQL
            $rowCount = $oSqlCmd.ExecuteNonQuery()
        }
        catch {
			$err = $_
            #Write-Debug $err
            $sCrashLog = 'C:\Users\'+$env:USERNAME+'\DNSQueryTableCrashLog.csv'
            $oDataTable | Export-Csv -Path $sCrashLog -ErrorAction SilentlyContinue
            $textOut = 'An error has occured.  A log file of the data that cause the crash has been written here:'
            Write-Debug $textOut
            Write-Debug $sCrashLog
            $sDesc = $textOut + "`n" + $sCrashLog
            $eventLog.WriteEntry($sDesc,$eventType,$eventID)
            $sDesc = $err.Exception.Message.ToString() + "`nLine " + `
                $err.get_InvocationInfo().ScriptLineNumber.ToString() + ": " + $err.get_InvocationInfo().Line + "`n"
            $eventLog.WriteEntry($sDesc,$eventType,$eventID)
            throw $err
        }
    }
    function Get-SqlErrorNextAttempt([System.Management.Automation.ErrorRecord] $err, [int] $iSecDelay) {
        # Input:    An error object, the number of seconds in the future to add if the error matches
        # Returns:  The current date time if the error is one we don't care about
        #           A future date time if the error matches one to act on
        $dtReturned = Get-Date
        if ($err.FullyQualifiedErrorId.ToString() -ne 'SqlException') {
            return $dtReturned
        }
        $sErrorRecord = $dtReturned.ToString()+'  '+$err.Exception.Message.ToString()
        $sTextOut = "Found SQL error: `n"+$sErrorRecord + "`nLine " + `
            $err.get_InvocationInfo().ScriptLineNumber.ToString() + ": " + $err.get_InvocationInfo().Line + "`n"
        if ($sErrorRecord.Contains('Exception calling "Open"') `
        -or $sErrorRecord.Contains('Connection Timeout Expired')) {
            # $oSqlConn.Open() failed to find the SQL server or a specific SQL instance
            Write-Debug $sTextOut
            return $dtReturned.AddSeconds($iSecDelay)
        }
        if ($sErrorRecord.Contains('Exception calling "ExecuteNonQuery"')) {
            # Connection opened OK, SQL server could not find the stored procedure to run it
            # Connection opened OK, we tried to run the stored procedure but something within the SQL server failed to run
            if ($sErrorRecord.Contains('Could not find stored procedure') `
            -or $sErrorRecord.Contains('Timeout expired') `
            -or $sErrorRecord.Contains('Database Engine cannot obtain a LOCK resource at this time') `
            -or $sErrorRecord.Contains('was deadlocked on lock resources')) {
                $sDesc = $sErrorRecord
                $eventLog.WriteEntry($sDesc,$eventType,$eventID)
                Write-Debug $sTextOut
                return $dtReturned.AddSeconds($iSecDelay)
            }
        }
        return $dtReturned
    } # End Get-SqlErrorNextAttempt
    function Try-SqlUploadAndHandleError($oSqlTracking) { 
        $dtNow = Get-Date
        # Send our table to be uploaded to SQL and start over fresh
        # We need skip SQL upload until it is time because of a previous error
        if ($dtNow -ge $oSqlTracking.dtSqlNextAttempt) { 
            $err = $null
            try {
                $oSqlConn.Open()
                Upload-DataTableToSqlDnsServerRecordLogging $oSqlConn $oSqlTracking.oTable
                $oSqlConn.Close()
                $oSqlTracking.oTable = DnsLogTableFactory
                $sTextOut = $oSqlTracking.iBatchCount.ToString()+" count reached"
				Write-Debug $sTextOut
        		$oSqlTracking.iBatchCount = 0
                $oSqlTracking.iSqlErrorRetryCount = 0
                return
            }
            catch [Exception] {
                # Note: if error contains 'A transport-level error has occurred'
                # Connection opened OK, something happened to the connection in the middle 
                # of the transaction.  We need to start over with a new connection after a few minutes
                # so let this error get passed up instead of handled by Get-SqlErrorNextAttempt
                $err = $_
                $oSqlConn.Close()
                $sTextOut = 'Unprocessed batch count: '+$oSqlTracking.iBatchCount.ToString()
                Write-Debug $sTextOut
                # Check for SQL error
                $oSqlTracking.dtSqlNextAttempt = Get-SqlErrorNextAttempt $err $oSqlTracking.iSqlErrorWaitTime
                $dtNow = Get-Date
                if ($oSqlTracking.dtSqlNextAttempt -le $dtNow) {
                    # Error is not SQL related, no reason to wait for anything
                    $sDesc = $dtNow.ToString() + $err.Exception.Message.ToString() + "`nLine " + `
                        $err.get_InvocationInfo().ScriptLineNumber.ToString() + ": " + $err.get_InvocationInfo().Line + "`n"
                    $eventLog.WriteEntry($sDesc,$eventType,$eventID)
                    throw $err
                } 
                else {
                    $oSqlTracking.iSqlErrorRetryCount++
                    # And just eat the error for now
                }
            }
        }
        if ($oSqlTracking.iSqlErrorRetryCount -ge $oSqlTracking.iSqlErrorRetryMax) {
            # Max number of SQL retries reached
            $oSqlConn.Close()
            $sDesc = $dtNow.ToString() + $err.Exception.Message.ToString() + "`nLine " + `
                $err.get_InvocationInfo().ScriptLineNumber.ToString() + ": " + $err.get_InvocationInfo().Line + "`n"
            $eventLog.WriteEntry($sDesc,$eventType,$eventID)
            throw $err
        }
    } # End Try-SqlUploadAndHandleError
    function Create-SqlTrackingObject() {
        $oSqlTracking = New-Object -TypeName System.Management.Automation.PSObject
        Add-Member -InputObject $oSqlTracking -MemberType NoteProperty -Name iBatchMax -Value 500  # Number of records to batch.
        Add-Member -InputObject $oSqlTracking -MemberType NoteProperty -Name iBatchCount -Value 0
        Add-Member -InputObject $oSqlTracking -MemberType NoteProperty -Name iSqlErrorRetryMax -Value 3  # Number of times to retry after and SQL error
        Add-Member -InputObject $oSqlTracking -MemberType NoteProperty -Name iSqlErrorRetryCount -Value 0  # A counter, the number of SQL errors we have seen
        Add-Member -InputObject $oSqlTracking -MemberType NoteProperty -Name iSqlErrorWaitTime -Value 180  # Number of seconds to wait after an SQL error
        Add-Member -InputObject $oSqlTracking -MemberType NoteProperty -Name dtSqlNextAttempt -Value ([datetime] '2001-01-01 00:00:01')
        Add-Member -InputObject $oSqlTracking -MemberType NoteProperty -Name oTable -Value $null
        ,$oSqlTracking
    }
    function Sleep-Until([Datetime] $dtFuture) {
        $dtNow = Get-Date
        $iSec = [System.Math]::ceiling(($dtFuture - $dtNow).totalseconds)
        if ($iSec -gt 0) {
            Start-Sleep -Seconds $iSec 
        } else { return }
    }
    function Wait-ForFileCreation([int] $iTotalLoops, [int] $iSecPause, [string] $sFilePath) {
        for ($i = 0; $i -lt $iTotalLoops; $i++) {
            if ( Test-Path $sFilePath ) {
                break
            }
        	Start-Sleep $iSecPause
        }
    }
    # Setup error logging object
    $eventLog = New-Object System.Diagnostics.EventLog
    $eventType = [System.Diagnostics.EventLogEntryType]::Error
    $eventID = 400
    $eventLog.Log = "Application"
    $eventLog.Source = "DNS_DebugLogLine_Logging"
    
    $regLine1 = Create-ReqRespLineRegex
    $regQParSep = [regex] '(\(\d{1,3}\))' # Looking for '(5)' that separage the subdomain strings
} # End Begin section
Process {
    if (($null -eq $DnsServerName) -or ($DnsServerName -eq '') -or ($DnsServerName -eq '.')) {
        # Try to get the DNS server name automatically.  Cannot assume the file being processed is still on the DNS server
        if ($DnsDebugLogFilePath -eq ($env:windir+'\system32\dns\dns.log')) {
            $oComputer = Get-WmiObject Win32_ComputerSystem
            $sDnsServerFQName = ($oComputer.Name+'.'+$oComputer.Domain).ToLower()
        }
        else {
            throw 'Unable to get DnsServerName.  Please pass in a fully qualified name.'
        }
    }
    else {
        $sDnsServerFQName = $DnsServerName.ToLower()
    }
    $sPSComputerName = (Get-WmiObject Win32_ComputerSystem).Name
    $sPSComputerTzOffset = (Get-Date -UFormat %Z) # String +/-00 from GMT
    # Try to automatically get the DNS server timezone offset
    if ($sDnsServerFQName.Contains($sPSComputerName)) {
        # Name is the same so use the same TZ
        $DnsServerTzOffset = $sPSComputerTzOffset
    }
    else {
        if ($DnsServerTzOffset -eq '') {
            throw 'Unable to get DnsServerTzOffset.  Please pass in a string of the timezone offset.'
        }
        # Nothing to be done for else because the timezone is already set
    }
    Write-Verbose "Reading contents of $DnsDebugLogFilePath"
    $oSqlTracking = Create-SqlTrackingObject
    $oSqlTracking.oTable = DnsLogTableFactory
    if ( $t ) { # Tail the file one line at a time.  
        $bolLoop = $true
        while ($bolLoop) {  # Used for multiple file read attempts
            $oSqlTracking.iBatchCount = 0
            Try {
                Get-Content $DnsDebugLogFilePath -Tail 0 -Wait -ErrorAction Stop | ForEach-Object {
                    if ($null -eq $_) {
                        return # Return out of this (non-existent pipeline object)
                    }
                    Parse-DnsDebugLogLineToDataTable @($_) $regLine1 $oSqlTracking.oTable
                    $oSqlTracking.iBatchCount++
                    if ($oSqlTracking.iBatchCount -ge $oSqlTracking.iBatchMax) {
						# The idea here is even if our SQL fails, we need to keep
						# reading the log file no matter what.
                        $sTextOut = '$oSqlTracking.oTable.Rows.Count is: '+$oSqlTracking.oTable.Rows.Count.ToString()
                        #Write-Debug $sTextOut
                        Try-SqlUploadAndHandleError $oSqlTracking
                        Setup-EventLogging
                    } # End  if ($iBatchCount -ge $iBatchMax)
                } # End  ForEach-Object
            } # End Try
            Catch [Exception] {
                $err = $_
                switch ($err.FullyQualifiedErrorId.ToString()) {
                	'GetContentReaderIOError,Microsoft.PowerShell.Commands.GetContentCommand' {
                		# File is changed while we are watching it.  Failure to initially 
                        # read the file is a different type of error from this one.
                        # Wait 5 Seconds for file to be recreated
                        Wait-ForFileCreation 5 1 $DnsDebugLogFilePath 
                		break
                	}
                	default {
                        $bolLoop = $false
                        $sDesc = $err.Exception.Message.ToString() + "`nLine " + `
                        $err.get_InvocationInfo().ScriptLineNumber.ToString() + ": " + $err.get_InvocationInfo().Line + "`n"
                        $eventLog.WriteEntry($sDesc,$eventType,$eventID)
                        throw $err
                		break
                	}
                }
            }
        }

    } # End  if (-t)
    else { # Read entire file
        Get-Content $DnsDebugLogFilePath | ForEach-Object {
            Parse-DnsDebugLogLineToDataTable @($_) $regLine1 $oSqlTracking.oTable
            $oSqlTracking.iBatchCount++
            if ($oSqlTracking.iBatchCount -ge $oSqlTracking.iBatchMax) {
                # Need to take a break from processing file if we didn't upload to SQL previously
                Sleep-Until $oSqlTracking.dtSqlNextAttempt
                $sTextOut = '$oSqlTracking.oTable.Rows.Count is: '+$oSqlTracking.oTable.Rows.Count.ToString()
                Write-Debug $sTextOut
                Try-SqlUploadAndHandleError $oSqlTracking
            } # End  if ($iBatchCount -ge $iBatchMax)      
        }
    }
    # Send any remaining that are less than batch count
    # We are going to only try once to get this last batch to SQL
    Sleep-Until $oSqlTracking.dtSqlNextAttempt
    Try-SqlUploadAndHandleError $oSqlTracking
} # End Process
} # End Get-DnsDebugLogLineToSql

function Start-Get-DnsDebugLogLineToSql() {
    # This contents can go in some other script and passed to the Get-DnsDebugLogLineToSql function
    Setup-EventLogging
    
    #$DnsDebugLogFilePath = $env:windir+'\system32\dns\dns.log'
    $DnsDebugLogFilePath = 'C:\Windows\System32\dns\dns.log'
    $DnsServerName = '.' # Fully Qualified Domain Name, use '.' to indicate local machine 
    $DnsServerTzOffset = (Get-Date -UFormat %Z) # Optional, String +/-00 from GMT
    $IgnoreQryType = @('PTR') # Optional
    
    # Setup SQL Connection
    $sSqlSec = 'SSPI'
    $sSqlServer = 'phl-bus-sql1'
    $sSqlDb = 'DNS_Logging'
    $sSqlConnString = "Integrated Security = $sSqlSec; Server = $sSqlServer; Database = $sSqlDb;"
    $oSqlConn = New-Object System.Data.SqlClient.SqlConnection
    $oSqlConn.ConnectionString = $sSqlConnString
    Get-DnsDebugLogLineToSql -DnsDebugLogFilePath $DnsDebugLogFilePath -oSqlConn $oSqlConn `
                             -DnsServerName $DnsServerName -DnsServerTzOffset $DnsServerTzOffset `
                             -IgnoreQryType $IgnoreQryType -t
}

Start-Get-DnsDebugLogLineToSql

